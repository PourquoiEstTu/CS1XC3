/**
 * @file main.c
 * @author Roshaan Quyum (quyumr@mcmaster.ca)
 * @brief a program to show outputs of functions from the course.c and student.c files
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief shows results of some functions from the course.c and student.c files
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
  
  /* enrolls a group of randomly generated students
   *into the course MATH101
  */
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  //prints the number of students passing MATH1O1
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}