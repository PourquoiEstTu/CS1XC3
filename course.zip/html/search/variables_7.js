var searchData=
[
  ['total_5fstudents_0',['total_students',['../struct__course.html#afd5e161f7cf358c13cc8aa868b462006',1,'_course']]]
];
