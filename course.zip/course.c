/**
 * @file course.c
 * @author Roshaan Quyum (quyumr@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Enroll/adds a student into a course
 * 
 * @param course a course a student could take, represented as a pointer
 * @param student a student which could take a course, represented as a pointer
 * @return void 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    /* If there is more than one student, it is quicker to reallocate
     * the space than clearing it all and allocating the space again
    */
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief prints all the course info for one course stored by the struct/typedef Course
 * 
 * @param course a course a student could take, represented as a pointer
 * @return void
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //prints all the students in the course
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief returns the student with the highest average in the course
 * 
 * @param course a course a student could take, represented as a pointer
 * @return Student* a pointer to the student with the highest average in the course 
 */
Student* top_student(Course* course)
{ 
  /*If a course doesn't have any students, then
   * there isn't a student with the top grade
   */
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  
  /*cycles through all the students taking the course to
   * check which one has the highest average
  */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief returns an array of all the students passing their courses
 * 
 * @param course a course a student could take, represented as a pointer
 * @param total_passing a count of the total number of students passing the course
 * @return Student* an array of students passing the course
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //counts the number of total students passing their courses
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  /* array is allocated all at once to prevent a lot of 
   *reallocations in another loop
  */
  passing = calloc(count, sizeof(Student));

  /* adds all the students passing their courses into the 
   *passing array
  */
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  /* a pointer keeping track of the total number of 
   *that are passing their courses 
  */
  *total_passing = count;

  return passing;
}